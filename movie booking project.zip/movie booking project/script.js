document.addEventListener("DOMContentLoaded", () => {
    const signupForm = document.getElementById("signupForm");
    const loginForm = document.getElementById("loginForm");
    const logoutBtn = document.getElementById("logoutBtn");
    const welcomeUser = document.getElementById("welcomeUser");
    const movieTitle = document.getElementById("movieTitle");
    const seatGrid = document.getElementById("seatGrid");
    const seatCount = document.getElementById("seatCount");
    const totalPrice = document.getElementById("totalPrice");
    const proceedPayment = document.getElementById("proceedPayment");
    const payMovieName = document.getElementById("payMovieName");
    const payAmount = document.getElementById("payAmount");
    const confirmPayment = document.getElementById("confirmPayment");

    // Sign Up
    if (signupForm) {
        signupForm.addEventListener("submit", (e) => {
            e.preventDefault();
            const name = document.getElementById("signupName").value;
            const email = document.getElementById("signupEmail").value;
            const password = document.getElementById("signupPassword").value;

            const user = { name, email, password };
            localStorage.setItem("movioUser", JSON.stringify(user));
            localStorage.setItem("movioLoggedIn", "true");

            window.location.href = "movies.html";
        });
    }

    // Login
    if (loginForm) {
        loginForm.addEventListener("submit", (e) => {
            e.preventDefault();
            const email = document.getElementById("loginEmail").value;
            const password = document.getElementById("loginPassword").value;
            const storedUser = JSON.parse(localStorage.getItem("movioUser"));

            if (storedUser && storedUser.email === email && storedUser.password === password) {
                localStorage.setItem("movioLoggedIn", "true");
                window.location.href = "movies.html";
            } else {
                alert("Invalid login details");
            }
        });
    }

    // Movies Page
    if (welcomeUser) {
        const loggedIn = localStorage.getItem("movioLoggedIn");
        const storedUser = JSON.parse(localStorage.getItem("movioUser"));

        if (!loggedIn) {
            window.location.href = "login.html";
        } else {
            welcomeUser.textContent = `Welcome, ${storedUser.name}`;
        }
    }

    // Book Movie
    window.bookMovie = function(movie) {
        localStorage.setItem("selectedMovie", movie);
        window.location.href = "booking.html";
    };

    // Booking Page
    if (movieTitle) {
        const movie = localStorage.getItem("selectedMovie");
        if (!movie) window.location.href = "movies.html";
        movieTitle.textContent = `Booking for ${movie}`;

        let selectedSeats = 0;
        let pricePerSeat = 200;

        // Generate seats
        for (let i = 1; i <= 30; i++) {
            let seat = document.createElement("div");
            seat.classList.add("seat");
            seat.textContent = i;
            seat.addEventListener("click", () => {
                seat.classList.toggle("selected");
                selectedSeats = document.querySelectorAll(".seat.selected").length;
                seatCount.textContent = selectedSeats;
                totalPrice.textContent = selectedSeats * pricePerSeat;
            });
            seatGrid.appendChild(seat);
        }

        proceedPayment.addEventListener("click", () => {
            localStorage.setItem("totalSeats", selectedSeats);
            localStorage.setItem("totalPrice", selectedSeats * pricePerSeat);
            window.location.href = "payment.html";
        });
    }

    // Payment Page
    if (payMovieName) {
        payMovieName.textContent = localStorage.getItem("selectedMovie");
        payAmount.textContent = localStorage.getItem("totalPrice");

        confirmPayment.addEventListener("click", () => {
            alert("Payment successful! Enjoy your movie 🎬");
            localStorage.removeItem("selectedMovie");
            localStorage.removeItem("totalSeats");
            localStorage.removeItem("totalPrice");
            window.location.href = "movies.html";
        });
    }

    // Logout
    if (logoutBtn) {
        logoutBtn.addEventListener("click", () => {
            localStorage.removeItem("movioLoggedIn");
            window.location.href = "login.html";
        });
    }
});
document.addEventListener('DOMContentLoaded', () => {
    const seats = document.querySelectorAll('.seat');
    const seatCount = document.getElementById('seatCount');
    const totalPrice = document.getElementById('totalPrice');
    const pricePerSeat = 150;

    let selectedSeats = 0;

    seats.forEach(seat => {
        seat.addEventListener('click', () => {
            seat.classList.toggle('selected');
            selectedSeats = document.querySelectorAll('.seat.selected').length;
            seatCount.innerText = selectedSeats;
            totalPrice.innerText = selectedSeats * pricePerSeat;
        });
    });

    document.getElementById('proceedPayment').addEventListener('click', () => {
        window.location.href = 'payment.html';
    });
});
document.addEventListener('DOMContentLoaded', () => {
    const seats = document.querySelectorAll('.seat.available');
    const seatCount = document.getElementById('seatCount');
    const totalPrice = document.getElementById('totalPrice');
    const pricePerSeat = 150;
    let selectedSeats = 0;

    seats.forEach(seat => {
        seat.addEventListener('click', () => {
            seat.classList.toggle('selected');
            selectedSeats = document.querySelectorAll('.seat.selected').length;
            seatCount.innerText = selectedSeats;
            totalPrice.innerText = selectedSeats * pricePerSeat;
        });
    });

    document.getElementById('proceedPayment').addEventListener('click', () => {
        if (selectedSeats > 0) {
            window.location.href = 'payment.html';
        } else {
            alert("Please select at least one seat!");
        }
    });
});
// LOGIN FORM HANDLING
document.addEventListener("DOMContentLoaded", () => {
    const loginForm = document.getElementById("loginForm");
    if (loginForm) {
        loginForm.addEventListener("submit", function(e) {
            e.preventDefault(); // stop page reload

            // You can add actual login checks here
            alert("Login successful! 🎉 Redirecting...");
            window.location.href = "movies.html"; // go to movies list
        });
    }
}); // SIGNUP FORM HANDLING
document.addEventListener("DOMContentLoaded", () => {
    const signupForm = document.getElementById("signupForm");
    if (signupForm) {
        signupForm.addEventListener("submit", function(e) {
            e.preventDefault();

            alert("Account created successfully! 🎉 Redirecting to movies...");
            window.location.href = "movies.html";
        });
    }
});
document.addEventListener("DOMContentLoaded", () => {
    // LOGIN PAGE HANDLING
    const loginForm = document.getElementById("loginForm");
    if (loginForm) {
        loginForm.addEventListener("submit", function(e) {
            e.preventDefault();
            alert("Login successful! 🎉 Redirecting...");
            setTimeout(() => {
                window.location.href = "movies.html";
            }, 800); // short delay for animation
        });
    }

    // SIGNUP PAGE HANDLING
    const signupForm = document.getElementById("signupForm");
    if (signupForm) {
        signupForm.addEventListener("submit", function(e) {
            e.preventDefault();
            alert("Account created successfully! 🎉 Redirecting...");
            setTimeout(() => {
                window.location.href = "movies.html";
            }, 800);
        });
    }
});
document.addEventListener("DOMContentLoaded", () => {
    const loginForm = document.getElementById("loginForm");
    const signupForm = document.getElementById("signupForm");

    if (loginForm) {
        loginForm.addEventListener("submit", function(e) {
            e.preventDefault();
            alert("Login successful! 🎉 Redirecting...");
            setTimeout(() => {
                window.location.href = "movies.html";
            }, 800);
        });
    }

    if (signupForm) {
        signupForm.addEventListener("submit", function(e) {
            e.preventDefault();
            alert("Signup successful! 🎉 Redirecting...");
            setTimeout(() => {
                window.location.href = "movies.html";
            }, 800);
        });
    }
});
// Proceed to payment
document.getElementById("proceedBtn").addEventListener("click", () => {
    if (selectedSeats.length === 0) {
        alert("Please select at least one seat before proceeding!");
        return;
    }

    // Save selected seats & total price to localStorage
    localStorage.setItem("selectedSeats", JSON.stringify(selectedSeats));
    localStorage.setItem("totalPrice", selectedSeats.length * seatPrice);

    // Redirect to payment page
    window.location.href = "payment.html";
});


